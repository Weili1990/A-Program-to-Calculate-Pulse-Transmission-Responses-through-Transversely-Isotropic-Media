% The reflection coefficients and the directivity patterns
% Inputs:
    %sita- the phase angle;
    %C- the rotated elastic stiffness matrix;
    %spxyz, ssvxyz, sshxyz- the slowness components of P-wave, SV-wave, and SH-wave
    %polipxyz, polisvxyz, polishxyz- the polarization components of P-wave, SV-wave, and SH-wave
    %vgpxyz, vgsvxyz, vgshxyz- the group velocity components of P-wave, SV-wave and SH-wave
% Outputs:
    %di- the magnitude of directivity pattern
% The function can also offer (Please add them to the function output if you need):
    %dixyz- the components of directivity pattern
    %repaco- the amplitude reflection coefficient of reflected P-wave
    %resvaco- the amplitude reflection coefficient of reflected SV-wave
    %repnco- the energy reflection coefficient of reflected P-wave
    %resvnco- the energy reflection coefficient of reflected SV-wave
    %total- the summation of the energy reflection coefficients (should always equal 1.0)
%The globle variables are defined in the main function
function di=Directivity(sita, C, spxyz, ssv, ssvxyz, sshxyz, polipxyz, polisvxyz, polishxyz, vgpxyz, vgsvxyz, vgshxyz)
global n f density wavemode force;
ins=zeros(3,n);%slowness components of incident wave
inn=zeros(3,n);%wave vector components of incident wave
inp=zeros(3,n);%polirization components of incident wave
invg=zeros(3,n);%group velocity components of incident wave
reps=zeros(3,n);%slowness components of reflected qP-wave
repn=zeros(3,n);%wave vector components of reflected qP-wave
resvs=zeros(3,n);%slowness components of reflected qSV-wave
resvn=zeros(3,n);%wave vector components of reflected qSV-wave
repaco=zeros(1,n);%amplitude reflection coefficient of reflected qP-wave
resvaco=zeros(1,n);%amplitude reflection coefficient of reflected qSV-wave
repnco=zeros(1,n);%energy reflection coefficient of reflected qP-wave
resvnco=zeros(1,n);%energy reflection coefficient of reflected qSV-wave
di=zeros(1,n);%directivity pattern  on a half surface
dixyz=zeros(3,n);%components of the directivity pattern on a half surface
total=zeros(1,n);
flagwave=zeros(1,n);
for i=1:n
    if (abs(wavemode-1)<10^(-6))
        ins(1,i)=-spxyz(1,i);
        ins(3,i)=-spxyz(3,i);
        inn(1,i)=-2*pi*f*spxyz(1,i);
        inn(3,i)=-2*pi*f*spxyz(3,i);
        inp(1,i)=-polipxyz(1,i);
        inp(3,i)=-polipxyz(3,i);
        invg(1,i)=-vgpxyz(1,i);
        invg(3,i)=-vgpxyz(3,i);
    end
    if (abs(wavemode-2)<10^(-6))
        ins(1,i)=-ssvxyz(1,i);
        ins(3,i)=-ssvxyz(3,i);
        inn(1,i)=-2*pi*f*ssvxyz(1,i);
        inn(3,i)=-2*pi*f*ssvxyz(3,i);
        inp(1,i)=-polisvxyz(1,i);
        inp(3,i)=-polisvxyz(3,i);
        invg(1,i)=-vgsvxyz(1,i);
        invg(3,i)=-vgsvxyz(3,i);
    end
    if (abs(wavemode-3)<10^(-6))
        ins(1,i)=-sshxyz(1,i);
        ins(3,i)=-sshxyz(3,i);
        inn(1,i)=-2*pi*f*sshxyz(1,i);
        inn(3,i)=-2*pi*f*sshxyz(3,i);
        inp(1,i)=-polishxyz(1,i);
        inp(3,i)=-polishxyz(3,i);
        invg(1,i)=-vgshxyz(1,i);
        invg(3,i)=-vgshxyz(3,i);
    end
    if (invg(3,i)>=-10^(-6))
        continue;
    end
    reps(1,i)=ins(1,i);
    repn(1,i)=inn(1,i);
    resvs(1,i)=ins(1,i);
    resvn(1,i)=inn(1,i);
    % Solving six-order equation. Equations (13) to (20). (See also Rokhlin,1986)
    zAA1=[C(1,1)*ins(1,i)^2-density, C(6,1)*ins(1,i)^2, C(5,1)*ins(1,i)^2]';
    zAA2=[C(1,6)*ins(1,i)^2, C(6,6)*ins(1,i)^2-density, C(5,6)*ins(1,i)^2]';
    zAA3=[C(1,5)*ins(1,i)^2, C(6,5)*ins(1,i)^2, C(5,5)*ins(1,i)^2-density]';
    zBB1=[(C(5,1)+C(1,5))*ins(1,i), (C(4,1)+C(6,5))*ins(1,i), (C(3,1)+C(5,5))*ins(1,i)]';
    zBB2=[(C(5,6)+C(1,4))*ins(1,i), (C(4,6)+C(6,4))*ins(1,i), (C(3,6)+C(5,4))*ins(1,i)]';
    zBB3=[(C(5,5)+C(1,3))*ins(1,i), (C(4,5)+C(6,3))*ins(1,i), (C(3,5)+C(5,3))*ins(1,i)]';
    zDD1=[C(5,5), C(4,5), C(3,5)]';
    zDD2=[C(5,4), C(4,4), C(3,4)]';
    zDD3=[C(5,3), C(4,3), C(3,3)]';
    zA=det([zAA1, zAA2, zAA3]);
    zB=det([zAA1, zAA2, zBB3])+ det([zAA1, zBB2, zAA3])+ det([zBB1, zAA2, zAA3]);
    zC=det([zAA1, zAA2, zDD3])+ det([zAA1, zBB2, zBB3])+ det([zAA1, zDD2, zAA3])+ det([zBB1, zAA2, zBB3])+ det([zBB1, zBB2, zAA3])+ det([zDD1, zAA2, zAA3]);
    zD=det([zAA1, zBB2, zDD3])+ det([zAA1, zDD2, zBB3])+ det([zBB1, zAA2, zDD3])+ det([zBB1, zBB2, zBB3])+ det([zBB1, zDD2, zAA3])+ det([zDD1, zAA2, zBB3])+ det([zDD1, zBB2, zAA3]);
    zE=det([zAA1, zDD2, zDD3])+ det([zBB1, zBB2, zDD3])+ det([zBB1, zDD2, zBB3])+ det([zDD1, zAA2, zDD3])+ det([zDD1, zBB2, zBB3])+ det([zDD1, zDD2, zAA3]);
    zF=det([zBB1, zDD2, zDD3])+ det([zDD1, zBB2, zDD3])+ det([zDD1, zDD2, zBB3]);
    zG=det([zDD1, zDD2, zDD3]);
    answer=roots([zG zF zE zD zC zB zA]);
    answer(abs(imag(answer))<10^(-6))=real(answer(abs(imag(answer))<10^(-6)));
    answer=unique(answer);
    G11=C(1,1)*ins(1,i)^2+C(5,5)*answer.^2+(C(1,5)+C(5,1))*ins(1,i)*answer-density;
    G12=C(1,6)*ins(1,i)^2+C(5,4)*answer.^2+(C(1,4)+C(5,6))*ins(1,i)*answer;
    G13=C(1,5)*ins(1,i)^2+C(5,3)*answer.^2+(C(1,3)+C(5,5))*ins(1,i)*answer;
    G22=C(6,6)*ins(1,i)^2+C(4,4)*answer.^2+(C(6,4)+C(4,6))*ins(1,i)*answer-density;
    G23=C(6,5)*ins(1,i)^2+C(4,3)*answer.^2+(C(6,3)+C(4,5))*ins(1,i)*answer;
    G33=C(5,5)*ins(1,i)^2+C(3,3)*answer.^2+(C(5,3)+C(3,5))*ins(1,i)*answer-density;
    G21=G12;
    G31=G13;
    G32=G23;
    W11=G22.*G33-G32.*G23;
    W22=G33.*G11-G13.*G31;
    W22(abs(W22)<10^(-6))=0;
    W33=G11.*G22-G21.*G12;
    W12=G31.*G23-G21.*G33;
    W31=G12.*G23-G13.*G22;
    W23=G31.*G12-G32.*G11;
    WW=W11+W22+W33;
    if( all(abs(WW)>10^(-6)) )
        P1=sqrt(W11./WW);
        P2=sqrt(W22./WW);
        P3=sqrt(W33./WW);
        P12=W12./WW;
        P31=W31./WW;
        P23=W23./WW;
        P2(abs(P1.*P2-P12)>10^(-6))=-P2(abs(P1.*P2-P12)>10^(-6));
        P3(abs(P1.*P3-P31)>10^(-6))=-P3(abs(P1.*P3-P31)>10^(-6));
        P3(abs(P2.*P3-P23)>10^(-6))=-P3(abs(P2.*P3-P23)>10^(-6));
        Vg3=( (C(5,1)*ins(1,i)+C(5,5)*answer).*P1.^2+ (C(4,6)*ins(1,i)+C(4,4)*answer).*P2.^2+ (C(3,5)*ins(1,i)+C(3,3)*answer).*P3.^2+...
        (C(5,6)*ins(1,i)+C(5,4)*answer).*P1.*P2+ (C(4,1)*ins(1,i)+C(4,5)*answer).*P2.*P1+ (C(5,5)*ins(1,i)+C(5,3)*answer).*P1.*P3+...
        (C(3,1)*ins(1,i)+C(3,5)*answer).*P3.*P1+ (C(4,5)*ins(1,i)+C(4,3)*answer).*P2.*P3+(C(3,6)*ins(1,i)+C(3,4)*answer).*P3.*P2 )/density;
        FLAG=( (abs(imag(answer))<10^(-6) & real(Vg3)>-10^(-6)) | imag(answer)>10^(-6) ) & (abs(P2)<10^(-6));
        vslowness=answer( FLAG );
        P1z=P1(FLAG);
        P2z=P2(FLAG);
        P3z=P3(FLAG);
        re1n(1)=2*pi*f*ins(1,i);
        re1n(3)=2*pi*f*vslowness(1);
        re1p(1)=P1z(1);
        re1p(2)=P2z(1);
        re1p(3)=P3z(1);
        re2n(1)=2*pi*f*ins(1,i);
        re2n(3)=2*pi*f*vslowness(2);
        re2p(1)=P1z(2);
        re2p(2)=P2z(2);
        re2p(3)=P3z(2);       
    end
    % Free surface boundary condition according to equation (22) and (23)
    zza(1,1)=0;
    zza(1,2)=0;
    zza(2,1)=0;
    zza(2,2)=0;
    zzb(1,1)=0;
    zzb(2,1)=0;
    for kkk=1:3
        for lll=1:3
            if (kkk==1 && lll==1)
                nn=1;
            end
            if (kkk==2 && lll==2)
                nn=2;
            end
            if (kkk==3 && lll==3)
                nn=3;
            end
            if ((kkk==1 && lll==2) || (kkk==2 && lll==1))
                nn=6;
            end
            if ((kkk==1 && lll==3) || (kkk==3 && lll==1))
                nn=5;
            end
            if ((kkk==2 && lll==3) || (kkk==3 && lll==2))
                nn=4;
            end
            zza(1,1)=zza(1,1)+C(3,nn)*re1p(kkk)*re1n(lll);
            zza(1,2)=zza(1,2)+C(3,nn)*re2p(kkk)*re2n(lll);
            zza(2,1)=zza(2,1)+C(5,nn)*re1p(kkk)*re1n(lll);
            zza(2,2)=zza(2,2)+C(5,nn)*re2p(kkk)*re2n(lll);
            zzb(1,1)=-(zzb(1,1)+C(3,nn)*inp(kkk,i)*inn(lll,i));
            zzb(2,1)=-(zzb(2,1)+C(5,nn)*inp(kkk,i)*inn(lll,i));
        end
    end
    zzx=zza\zzb; % two amplitude reflection coefficients.Here, don't know which is P-wave or which is SV-wave
    NFI=C(5,1)*(conj(inp(1,i))*inp(1,i)*inn(1,i)+inp(1,i)*conj(inp(1,i))*conj(inn(1,i)))+C(5,5)*(conj(inp(1,i))*inp(1,i)*inn(3,i)+inp(1,i)*conj(inp(1,i))*conj(inn(3,i)))+...
            C(5,5)*(conj(inp(1,i))*inp(3,i)*inn(1,i)+inp(1,i)*conj(inp(3,i))*conj(inn(1,i)))+C(5,3)*(conj(inp(1,i))*inp(3,i)*inn(3,i)+inp(1,i)*conj(inp(3,i))*conj(inn(3,i)))+...
            C(3,1)*(conj(inp(3,i))*inp(1,i)*inn(1,i)+inp(3,i)*conj(inp(1,i))*conj(inn(1,i)))+C(3,5)*(conj(inp(3,i))*inp(1,i)*inn(3,i)+inp(3,i)*conj(inp(1,i))*conj(inn(3,i)))+...
            C(3,5)*(conj(inp(3,i))*inp(3,i)*inn(1,i)+inp(3,i)*conj(inp(3,i))*conj(inn(1,i)))+C(3,3)*(conj(inp(3,i))*inp(3,i)*inn(3,i)+inp(3,i)*conj(inp(3,i))*conj(inn(3,i)));
    NFRP=C(5,1)*(conj(re1p(1))*re1p(1)*re1n(1)+re1p(1)*conj(re1p(1))*conj(re1n(1)))+C(5,5)*(conj(re1p(1))*re1p(1)*re1n(3)+re1p(1)*conj(re1p(1))*conj(re1n(3)))+...
             C(5,5)*(conj(re1p(1))*re1p(3)*re1n(1)+re1p(1)*conj(re1p(3))*conj(re1n(1)))+C(5,3)*(conj(re1p(1))*re1p(3)*re1n(3)+re1p(1)*conj(re1p(3))*conj(re1n(3)))+...
             C(3,1)*(conj(re1p(3))*re1p(1)*re1n(1)+re1p(3)*conj(re1p(1))*conj(re1n(1)))+C(3,5)*(conj(re1p(3))*re1p(1)*re1n(3)+re1p(3)*conj(re1p(1))*conj(re1n(3)))+...
             C(3,5)*(conj(re1p(3))*re1p(3)*re1n(1)+re1p(3)*conj(re1p(3))*conj(re1n(1)))+C(3,3)*(conj(re1p(3))*re1p(3)*re1n(3)+re1p(3)*conj(re1p(3))*conj(re1n(3)));
    NFRSV=C(5,1)*(conj(re2p(1))*re2p(1)*re2n(1)+re2p(1)*conj(re2p(1))*conj(re2n(1)))+C(5,5)*(conj(re2p(1))*re2p(1)*re2n(3)+re2p(1)*conj(re2p(1))*conj(re2n(3)))+...
              C(5,5)*(conj(re2p(1))*re2p(3)*re2n(1)+re2p(1)*conj(re2p(3))*conj(re2n(1)))+C(5,3)*(conj(re2p(1))*re2p(3)*re2n(3)+re2p(1)*conj(re2p(3))*conj(re2n(3)))+...
              C(3,1)*(conj(re2p(3))*re2p(1)*re2n(1)+re2p(3)*conj(re2p(1))*conj(re2n(1)))+C(3,5)*(conj(re2p(3))*re2p(1)*re2n(3)+re2p(3)*conj(re2p(1))*conj(re2n(3)))+...
              C(3,5)*(conj(re2p(3))*re2p(3)*re2n(1)+re2p(3)*conj(re2p(3))*conj(re2n(1)))+C(3,3)*(conj(re2p(3))*re2p(3)*re2n(3)+re2p(3)*conj(re2p(3))*conj(re2n(3)));  
    if(abs(invg(3,i))>10^(-6))  
        zzzx(1)=-abs(zzx(1))^2*NFRP/NFI;% two energy reflection coefficients
        zzzx(2)=-abs(zzx(2))^2*NFRSV/NFI;
    end
    if(abs(NFI)<10^(-6))
        zzzx(1)=zzx(1)^2;
        zzzx(2)=zzx(2)^2;
    end
    % the summation of engergy reflection coefficients and it should always equal one
    total(i)=zzzx(1)+zzzx(2);
%% directivity pattern calculation 
    if (total(i)>10^(-6))
        if (abs(force-1)<10^(-6))
            % What we need in the later calcualtion is the relative value.
            % Divding by 2 is just for plot and won't affect the relative shape of wavefield, wave beam, and received waveforms. 
            di(i)=abs(inp(3,i)+zzx(1)*re1p(3)+zzx(2)*re2p(3))/2.0; % equation (11)
        end
        if (abs(force-2)<10^(-6))
            di(i)=abs(inp(1,i)+zzx(1)*re1p(1)+zzx(2)*re2p(1))/2.0; % equation (12)
        end
        dixyz(1,i)=di(i)*sin(sita(i));
        dixyz(3,i)=di(i)*cos(sita(i));
    end
%% identify reflected wave modes
    if (exist('vslowness','var') )
    flagsv=sqrt(ins(1,i)^2+vslowness.*vslowness)>min(ssv)-10^(-2) & imag(vslowness)<10^(-6);
    flagwave(i)=sum(flagsv);
    if (abs(flagwave(i)-1.0)<10^(-6))
        resvaco(i)=zzx(flagsv);
        resvnco(i)=zzzx(flagsv);
        flagp=~flagsv;
        repaco(i)=zzx(flagp);
        repnco(i)=zzzx(flagp);
    end
    if (abs(flagwave(i)-2.0)<10^(-6))
        flagsv1=vslowness>max(vslowness)-10^(-6);
        resvaco(i)=zzx(flagsv1);
        resvnco(i)=zzzx(flagsv1);
        flagp=~flagsv1;
        repaco(i)=zzx(flagp);
        repnco(i)=zzzx(flagp);
    end
    end
end
%% Plot
if (abs(wavemode-1)<10^(-6) || abs(wavemode-2)<10^(-6))
figure(3);
sitaangle=sita/pi*180;
subplot(2,1,1);
hold on
plot(sitaangle,abs(repaco),'-black');
plot(sitaangle,abs(resvaco),'--black');
set(gca,'xtick',-180:90:180);
title('Solid line is P-wave; dash line is SV-wave');
xlabel('Incident angle'); 
ylabel('Amplitude reflection coefficients'); 
hold off
subplot(2,1,2);
hold on
plot(sitaangle,repnco,'-black');
plot(sitaangle,resvnco,'--black');
set(gca,'xtick',-180:90:180);
xlabel('Incident angle'); 
ylabel('Energy reflection coefficients'); 
hold off

figure(4)
plot(dixyz(1,:),dixyz(3,:),'--black');
title('Directivity pattern');
xlabel('Horizontal component'); 
ylabel('Vertical component'); 
set(gcf,'Position',[300 300 500 500]);
end