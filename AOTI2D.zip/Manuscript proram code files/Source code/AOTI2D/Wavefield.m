%The Function offers the wave field of the ultrasonic transduer in artitrarily oriented transverse isotropy
%Inputs:
    %vpp, vpsv, and vpsh- the magnitudes of phase velocity of P-wave, SV-wave, and SH-wave
    %vgp, vgsv, and vgsh- the magnitudes of group velocity of P-wave, SV-wave, and SH-wave
    %vgpxyz, vgsvxyz, and vgshxyz- the components of group velocity of P-wave, SV-wave, and SH-wave
    %polipxyz, polisvxyz, and polishxyz- the polarization components of P-wave, SV-wave, and SH-wave
    %di- magnitude of the directivity pattern
    %ln and lin- the vertical griding number and the vertical griding interval of the media
    %wn and win- the horizontal griding number and the horizontal grding interval of the media
    %time1- the propagation time
    %fet- the position of the first point source on the transducer. It is used to move the transmitter.
    %etn and etin- the griding number and the griding interval of the transmitter
%Outputs:
    %amli- the wave field of each point of the media
function ampli=Wavefield(vpp, vgp, vgpxyz, vpsv, vgsv, vgsvxyz, vpsh, vgsh, vgshxyz, polipxyz, polisvxyz, polishxyz, di, ln, lin, wn, win, time1, fet, etn, etin)
global n f wavemode;
etpo=zeros(1,etn);% position of each point source in the transmitter
vg=zeros(1,n); % group velocity
vgxyz=zeros(3,n); % components of group velocity
polixyz=zeros(3,n); % polarization
for i=1:n
    % input P, SV or SH wave parameters
    if (abs(wavemode-1)<10^(-6))
        vg(i)=vgp(i);
        vgxyz(1,i)=vgpxyz(1,i);
        vgxyz(3,i)=vgpxyz(3,i);
        polixyz(1,i)=polipxyz(1,i);
        polixyz(3,i)=polipxyz(3,i);
    end
    if (abs(wavemode-2)<10^(-6))
        vg(i)=vgsv(i);
        vgxyz(1,i)=vgsvxyz(1,i);
        vgxyz(3,i)=vgsvxyz(3,i);
        polixyz(1,i)=polisvxyz(1,i);
        polixyz(3,i)=polisvxyz(3,i);
    end
    if (abs(wavemode-3)<10^(-6))
        vg(i)=vgsh(i);
        vgxyz(1,i)=vgshxyz(1,i);
        vgxyz(3,i)=vgshxyz(3,i);
        polixyz(1,i)=polishxyz(1,i);
        polixyz(3,i)=polishxyz(3,i);
    end
end
% positions of the point sources
for i=1:etn
    etpo(i)=(i-1)*etin+(fet-1)*win;
end
ptime=zeros(ln,wn);% transit time from point (i,j) in the media to the k-th point source
amplix=zeros(ln,wn);% x component of total displacement at point (i,j)
ampliy=zeros(ln,wn);% y component of total displacement at point (i,j)
ampliz=zeros(ln,wn);% z component of total displacement at point (i,j)
ampli=zeros(ln,wn);% magnitude of total displacement at point (i,j)
dis=zeros(ln,wn);% distance between point (i,j) in the media and the k-th point source
cosdis=zeros(ln,wn);% direction cosine of point (i,j)
sindis=zeros(ln,wn);% direction sine of point (i,j)
vgroup=zeros(ln,wn);% group velocity calculated from interpolation for point (i,j)
amp=zeros(ln,wn);% directivity calculated from interpolation for point (i,j)
pox=zeros(ln,wn);% x-component of polarization calculated from interpolation for point (i,j)
poz=zeros(ln,wn);% z-component of polarization calculated from interpolation for point (i,j)
for i=2:ln
    for j=1:wn
        ampli(i,j)=0;
        amplix(i,j)=0;
        ampliy(i,j)=0;
        ampliz(i,j)=0;
        for k=1:etn
            dis(i,j)=sqrt( ( (j-1)*win-etpo(k) )^2+ ( (i-1)*lin )^2 );% distance between point (i,j) and the k-th point source according to equation (24)
            if(abs(dis(i,j))>10^(-6))
            cosdis(i,j)= ( (j-1)*win-etpo(k) )/ dis(i,j);
            sindis(i,j)= ( (i-1)*lin  )/ dis(i,j);
            end
            if(abs(dis(i,j))<10^(-6))
            cosdis(i,j)= 0;      
            end
            flag=0;
            % interpolation
            for ii=1:n-1
                if (abs(flag)>10^(-6))
                    flag=0;
                    continue;
                end
                if (vgxyz(3,ii)<0)
                    continue;
                end
                cosdis1=vgxyz(1,ii)/sqrt(vgxyz(1,ii)^2+vgxyz(3,ii)^2);
                cosdis2=vgxyz(1,ii+1)/sqrt(vgxyz(1,ii+1)^2+vgxyz(3,ii+1)^2);
                if( ((cosdis1-cosdis(i,j))*(cosdis2-cosdis(i,j))<=10^(-10)) )
                    flag=ii;
                    vgroup(i,j)=(cosdis(i,j)-cosdis1)/(cosdis2-cosdis1)*(vg(ii+1)-vg(ii))+vg(ii);%group velocity calculated from interpolation method
                    amp(i,j)=(cosdis(i,j)-cosdis1)/(cosdis2-cosdis1)*(di(ii+1)-di(ii))+di(ii);%displacement directivity factor calculated from interpolation method
                    pox(i,j)=(cosdis(i,j)-cosdis1)/(cosdis2-cosdis1)*(polixyz(1,ii+1)-polixyz(1,ii))+polixyz(1,ii);%horizongtal component of polarization
                    poz(i,j)=(cosdis(i,j)-cosdis1)/(cosdis2-cosdis1)*(polixyz(3,ii+1)-polixyz(3,ii))+polixyz(3,ii);%vertical component of polarization
                    ptime(i,j)=dis(i,j)/vgroup(i,j)*10.0;% transit time according to equation (25)
                    % Calculate the displacement at each point in the media according to equation (26)
                    if (abs(wavemode-1)<10^(-6) || abs(wavemode-2)<10^(-6))
                        rayamplitudex= pox(i,j)*amp(i,j)/dis(i,j)* ( 1-2*( pi*f*( time1-ptime(i,j)) )^2 )*exp( -(pi*f*(time1-ptime(i,j)))^2 );%Ricker wavelet is used as input signal (see equation (27))
                        rayamplitudez= poz(i,j)*amp(i,j)/dis(i,j)* ( 1-2*( pi*f*( time1-ptime(i,j)) )^2 )*exp( -(pi*f*(time1-ptime(i,j)))^2 );
                        amplix(i,j)= amplix(i,j)+ rayamplitudex;
                        ampliz(i,j)= ampliz(i,j)+ rayamplitudez;
                    end
                    if( abs(wavemode-3)<10^(-6) )
                        rayamplitudey= 2/dis(i,j)*( 1-2*( pi*f*( time1-ptime(i,j)) )^2 )*exp( -(pi*f*(time1-ptime(i,j)))^2 );
                        ampliy(i,j)= ampliy(i,j)+ rayamplitudey;
                    end
                end
            end            
        end
        %calculate the magnitude of displacement according to equation (28)
        if (abs(wavemode-1)<10^(-6))
            if (ampliz(i,j)>=0)
                ampli(i,j)= sqrt(amplix(i,j)^2+ampliz(i,j)^2);
            end
            if (ampliz(i,j)<0)
                ampli(i,j)= -sqrt(amplix(i,j)^2+ampliz(i,j)^2);
            end
        end
        if (abs(wavemode-2)<10^(-6))
            if (amplix(i,j)>=0)
                ampli(i,j)= sqrt(amplix(i,j)^2+ampliz(i,j)^2);
            end
            if (amplix(i,j)<0)
                ampli(i,j)= -sqrt(amplix(i,j)^2+ampliz(i,j)^2);
            end
        end
        if (abs(wavemode-3)<10^(-6))
            ampli(i,j)= ampliy(i,j);
        end
        if (abs(ampli(i,j))<10^(-6) )
            ampli(i,j)=0.0;
        end
    end
end
%% Plot snapshot of wave field
figure(5)
pcolor(ampli);
shading interp
set(gcf,'Position',[300 200 400 400]);
xlabel('Width, cm');
ylabel('Thickness, cm'); 
set(gca,'xtick',[1:(wn-1)/4.0:wn]);
set(gca,'xticklabel',{0 (wn-1)*win/4 2*(wn-1)*win/4 3*(wn-1)*win/4 (wn-1)*win});
set(gca,'ytick',[1:(ln-1)/4.0:ln]);
set(gca,'yticklabel',{0 (ln-1)*lin/4 2*(ln-1)*lin/4 3*(ln-1)*lin/4 (ln-1)*lin});
set(findobj('FontSize',14),'FontSize',14);
%generate a color bar
mincolor    = [0 0 1]; % red
mediancolor = [1 1 1]; % white
maxcolor    = [1 0 0]; % blue
colorx=caxis;
ColorMapSize1 = 20;
ColorMapSize2 = int16(20/abs(colorx(1))*abs(colorx(2)));
int1 = zeros(ColorMapSize1,3); 
int2 = zeros(ColorMapSize2,3);
for k=1:3
    int1(:,k) = linspace(mincolor(k), mediancolor(k), ColorMapSize1);
    int2(:,k) = linspace(mediancolor(k), maxcolor(k), ColorMapSize2);
end
meep = [int1(1:end-1,:); int2];
colormap(meep);
hold on
plot([fet,fet+(etn-1)*etin/win],[2,2],'red','LineWidth',4);
anglex= (n-1)/2+1;
if (abs(wavemode-1) < 10^(-6))
    cossita45= vpp(anglex)/vgp(anglex);
    if (vgpxyz(1,anglex) < -10^(-6))
        xxx= fet-sqrt(1-cossita45^2)/cossita45*(ln-1)*lin/win;% calculate the position wave beam arrive at the top receiving surface
    end
    if (vgpxyz(1,anglex) > -10^(-6))
        xxx= fet+sqrt(1-cossita45^2)/cossita45*(ln-1)*lin/win;% calculate the position wave beam arrive at the top receiving surface
    end
end
if (abs(wavemode-2) < 10^(-6))
    cossita45= vpsv(anglex)/vgsv(anglex);
    if (vgsvxyz(1,anglex) < -10^(-6))
        xxx= fet-sqrt(1-cossita45^2)/cossita45*(ln-1)*lin/win;% calculate the position wave beam arrive at the top receiving surface
    end
    if (vgsvxyz(1,anglex) > -10^(-6))
        xxx= fet+sqrt(1-cossita45^2)/cossita45*(ln-1)*lin/win;% calculate the position wave beam arrive at the top receiving surface
    end
end
if (abs(wavemode-3) < 10^(-6))
    cossita45= vpsh(anglex)/vgsh(anglex);
    if (vgshxyz(1,anglex) < -10^(-6))
        xxx= fet-sqrt(1-cossita45^2)/cossita45*(ln-1)*lin/win;% calculate the position wave beam arrive at the top receiving surface
    end
    if (vgshxyz(1,anglex) > -10^(-6))
        xxx= fet+sqrt(1-cossita45^2)/cossita45*(ln-1)*lin/win;% calculate the position wave beam arrive at the top receiving surface
    end
end
skewangle= acos(cossita45);% calculate the beam skew angle
skewdistance= sqrt(1-cossita45^2)/cossita45*(ln-1)*lin;% calculate the skewed distance of the wave beam
plot([fet+(etn-1)/2,fet+(etn-1)/2],[1,ln],'--red','LineWidth',1);% point out the straightforward direction
plot([fet+(etn-1)/2,xxx+(etn-1)/2],[1,ln],'--red','LineWidth',1);% point out the transit direction of the wave beam
hold off
