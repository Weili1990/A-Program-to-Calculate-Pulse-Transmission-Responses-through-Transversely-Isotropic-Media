The AOTI2D algorithm is short for the arbitrarily oriented transverse isotropy in 2-dementions

Copyright Wei Li 2017/07/05
Please report any bug to liwei2014@cugb.edu.cn

Referred manuscript title: "A Program to Calculate Pulse Transmission Responses through Transversely Isotropic Media".
Wei Li a,b,c, Douglas R. Schmitt b, Changchun Zou a,c, Xiwei Chen b
a School of Geophysics and Information Technology, China University of Geosciences(Beijing), Beijing, 100083, PR China
b Department of Physics, Institute for Geophysical Research, University of Alberta, Edmonton, AB T6G 2E1, Canada
c Key Laboratory of Geo-detection, China University of Geosciences(Beijing), Ministry of Education, Beijing, 100083, PR China
