%The function transforms the elastic stiffness matrix from material coordinate system to observation coordinate system
%Inputs:
    %C1- elastic stiffness matrix in material coordinate system
%Outputs:
    %C- elastic stiffness matrix in observation coordinate system
function C=Rotation(C1)
global alpha;
% components of the Bond rotation matrix according to equation (4)
M(1,1)=cos(alpha)^2;
M(2,2)=1;
M(3,3)=cos(alpha)^2;
M(4,4)=cos(alpha);
M(5,5)=cos(2*alpha);
M(6,6)=cos(alpha);
M(1,3)=sin(alpha)^2;
M(3,1)=sin(alpha)^2;
M(1,5)=-sin(2*alpha);
M(5,1)=1.0/2.0*sin(2*alpha);
M(3,5)=sin(2*alpha);
M(5,3)=-1.0/2.0*sin(2*alpha);
M(4,6)=sin(alpha);
M(6,4)=-sin(alpha);
C=M*C1*M.';% equation (3)