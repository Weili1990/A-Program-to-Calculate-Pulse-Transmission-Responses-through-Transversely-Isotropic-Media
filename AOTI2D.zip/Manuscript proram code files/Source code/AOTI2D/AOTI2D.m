% Copyright Wei Li 2017/07/05
% Please report any bug to liwei2014@cugb.edu.cn or wli3@ualberta.ca
% Referred manuscript title: "A Program to Calculate Pulse Transmission Responses through Transversely Isotropic Media".
% The AOTI2D algorithm is short for the arbitrarily oriented transverse isotropy in 2-dementions
% The algorithm provides the snapshot of wavefield, wave beam and received waveforms excited by the finite-sized ultrasonic transducer in arbitrarily oriented transversely isotropic media
% (Or the so-called HTI, TTI or VTI media)
% The algorithm also provides bacis charactes of the wave including phase velocity, polirization, group velocity, reflection coefficients, and directivity
clc
clear all
close all
tic
global n f alpha density wavemode force result;
%% Input parameters mainly contains: 
% basic parameters, media elastic properties,media size and resolution, transducer parameters, and time parameters
%% Basic parameters
f=1.0;% frequancy of the Ricker wavelet which is used as the input, MHz
alpha=-pi/4.0;% the tilt angle (expressed in radians) of the symmetric axis of the transversely isotropic media (the counterclockwise direction is defined as the positive direction)
wavemode=1;%=1 P-wave; =2 SV-wave; =3��SH-wave
force=1;%=1 normal force(P-wave transducer); =2 tangential force(S-wave transducer)
result=1;%=1 snapshot of wave field; =2 static wave beam; =3 received waveforms
%% Media elastic properties 
inputs=0;% =0 when the inputs are density and elastic constants; =1 when the inputs are density and phase velocities
% example 1: the shale sample 7-13 from Oliver and Schmitt (2015), Fig.5 to Fig.10 are plotted with these data.
density=2.48;%density of the media, g/cm3
C1(1,1)=68.41;%C1 is the elastic constant matrix in the material coordinate system, GPa
C1(3,3)=34.9;
C1(4,4)=14.3;
C1(6,6)=27.03;
C1(1,3)=12.0;
% example 2: austenitic steel (X6 Cr Ni 18 11) from Kolkoori (2013), Fig. A.1 and A.2 are plotted with these data
% density=7.82;
% C1(1,1)=241.1;
% C1(3,3)=240.12;
% C1(4,4)=112.29;
% C1(6,6)=72.092;
% C1(1,3)=138.03;

% you can also input the example 1 in the following form:
% density=2.48;%density of the media, g/cm3
% vp0=3.7513;%0 degree P-wave phase velocty(vertical to the foliation), km/s
% vp90=5.2521;%90 degree P-wave phase velocty(parallel to the foliation), km/s
% vsh0=2.4013;%0 degree SH-wave phase velocty(vertical to the foliation), km/s
% vsh90=3.3014;%90 degree SH-wave phase velocty(parallel to the foliation), km/s
% vp45=4.4252;%45 degree P-wave phase velocty (45 degree oblique to the foliation), km/s
%% Media size and resolution parameters
n=121;% meshing amount of the direction angle
ln=201;% meshing amount of media thickness
lin=0.05;% meshing interval of media thickness, cm
wn=201;% meshing amount of media width
win=0.05;% meshing interval of media width, cm
%% Transducer parameters
fet=101;% position of the point source on the left side of the transmitter
etn=41;% meshing amount of the transmitter
etin=0.05;% meshing interval of the transmitter, cm
nrecei=9;% receiver amount
rtn=41;% receiver meshing amount
rtin=0.05;% receiver meshing interval, cm
%% Time parameters
% used when result=1
time1=15;% snapshot time, us 
% used when result=3 (Parameters controlling the time window)
% For different cases, these parameters need to be changed to proper values so that the received waveforms could be observed in the time window range
timestart=15;% start time of the time window for the observation of received waveforms, us
dt=0.01;% time window meshing interval, us (used when result=3)
ntime=1501;% time window meshing amount (used when result=3)
%% Outputs:
% Subroutine "Velocitytostiffness.m":
    %C1- elastic stiffness matrix in material coordinate system
    %The function also provides the anisotropic coefficients (ita, delta, and gama). Please add them to the function output if you need.
% Subroutine "Rotation.m":
    %C- elastic stiffness matrix in observation coordinate system
% Subroutine "VpVgPoli.m":
    %vpp, vpsv, vpsh- phase velocities of P-wave, SV-wave, and SH-wave
    %vppxyz, vpsvxyz, vpshxyz- components of phase velocities of P-wave, SV-wave, and SH-wave
    %sp, ssv, ssh- slownesses of P-wave, SV-wave, and SH-wave
    %spxyz, ssvxyz, sshxyz- components of slownesses of P-wave, SV-wave, and SH-wave
    %polipxyz, polisvxyz, polishxyz- components of polarizations of P-wave, SV-wave, and SH-wave
    %vgp, vgsv, vgsh- group velocities of P-wave, SV-wave, and SH-wave
    %vgpxyz, vgsvxyz, vgshxyz- components of group velocities of P-wave, SV-wave, and SH-wave
% Subroutine "Directivity.m":
    %di- the magnitude of directivity pattern
    % The function can also offer (Please add them to the function output if you need):
        %dixyz- the components of directivity pattern
        %repaco- the amplitude reflection coefficient of reflected P-wave
        %resvaco- the amplitude reflection coefficient of reflected SV-wave
        %repnco- the energy reflection coefficient of reflected P-wave
        %resvnco- the energy reflection coefficient of reflected SV-wave
        %total- the summation of the energy reflection coefficients (should always equal 1.0)
% Subroutine "wavefield.m":
    %amli- the displacement of every point in the media
% Subroutine "wavebeam.m":
    %amli- the displacement of every point in the media
% Subroutine "signals.m":
    %pickuptime- the picked propagation time from the signal
%% Subroutines, the meanings of the referred inputs and outputs are introduced in front of each subroutine
etpo=zeros(1,etn);%positions of every point source on the transmitter
sita=zeros(1,n);% the direction angle ranging from -pi to pi
for i=1:n
    sita(i)=2*pi/(n-1)*(i-1)-pi; 
end
% the elastic constant matrix of transversely isotropic media (equation (2))
if (abs(inputs-0)<10^(-6))
    C1(2,2)=C1(1,1);
    C1(5,5)=C1(4,4);
    C1(1,2)=C1(1,1)-2*C1(6,6);
    C1(2,1)=C1(1,2);
    C1(3,1)=C1(1,3);
    C1(3,2)=C1(1,3);
    C1(2,3)=C1(1,3);
end
% Convert the phase velocities to elastic constants if the inputs are phase velocities 
if (abs(inputs-1)<10^(-6))
    C1=Velocitytostiffness(vp0, vsh0, vp90, vsh90, vp45);
end
% Rotate the elastic constants from the crystallgraphic coordinate to observation coordinate
C=Rotation(C1); % equations (4) and (5)
% Calculate phase velocities, polirizations, and group velocities according to equations (6) to (7)
[vpp, vppxyz, vpsv, vpsvxyz, vpsh, vpshxyz, sp, spxyz, ssv, ssvxyz, ssh, sshxyz, polipxyz, polisvxyz, polishxyz, vgp, vgpxyz, vgsv, vgsvxyz, vgsh, vgshxyz]=VpVgPoli(sita, C);
% Calculate the displacement directivity factors according to equations (9) to (23)
di=Directivity(sita, C, spxyz, ssv, ssvxyz, sshxyz, polipxyz, polisvxyz, polishxyz, vgpxyz, vgsvxyz, vgshxyz);
% Calculate the snapshot of wave field according to equations (24) to (28)
if ( abs(result-1)<10^(-6))
    ampli=Wavefield(vpp, vgp, vgpxyz, vpsv, vgsv, vgsvxyz, vpsh, vgsh, vgshxyz, polipxyz, polisvxyz, polishxyz, di, ln, lin, wn, win, time1, fet, etn, etin);
end
% Calculate the static wave beam according to equation (29)
if ( abs(result-2)<10^(-6))
    ampli=Wavebeam(vpp, vgp, vgpxyz, vpsv, vgsv, vgsvxyz, vpsh, vgsh, vgshxyz, polipxyz, polisvxyz, polishxyz, di, ln, lin, wn, win, fet, etn, etin);
end
% Calculate the received signals according to equations (30) to (32)
if ( abs(result-3)<10^(-6))
    pickuptime=Signals(vgp, vgpxyz, vgsv, vgsvxyz, vgsh, vgshxyz, polipxyz, polisvxyz, polishxyz, di, ln, lin, win, timestart, dt, ntime, nrecei, fet, etn, etin, rtn, rtin);
end
toc