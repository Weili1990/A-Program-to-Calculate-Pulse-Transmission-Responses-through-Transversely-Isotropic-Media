%The function generates elastic stiffness matrix from the phase velocities.
%Inputs:
    %density- the density of the media;
    %vp0- the P-wave phase velocity in the direction vertical to the foliation(0 degree);
    %vsh0- the SH-wave phase velocity in the direction vertical to the foliation(0 degree);
    %vp90- the P-wave phase velocity in the direction parallel to the foliation(90 degree);
    %vsh90- the SH-wave phase velocity in the direction parallel to the foliation(90 degree);
    %vsh45- the P-wave phase velocity in the 45 degree.
%Outputs:
    %C1- elastic stiffness matrix in material coordinate system
%The function also provides the anisotropic coefficients (ita, delta, and gama). Please add them to the function output if you need.
function C1=Velocitytostiffness(vp0, vsh0, vp90, vsh90, vp45)
global density;
C1=zeros(6,6);
C1(1,1)=density*vp90^2.0;
C1(2,2)=density*vp90^2.0;
C1(3,3)=density*vp0^2.0;
C1(4,4)=density*vsh0^2.0;
C1(5,5)=density*vsh0^2.0;
C1(6,6)=density*vsh90^2.0;
C1(1,2)=C1(1,1)-2*C1(6,6);
C1(2,1)=C1(1,2);
C1(1,3)=-C1(4,4)+sqrt( (C1(1,1)+C1(4,4)-2*density*vp45^2)*(C1(3,3)+C1(4,4)-2*density*vp45^2) );
C1(3,1)=C1(1,3);
C1(3,2)=C1(1,3);
C1(2,3)=C1(1,3);
% Thomsen anisotropic parameters
ita=(C1(1,1)-C1(3,3))/2.0/C1(3,3);
delta=( (C1(1,3)+C1(4,4))^2.0-(C1(3,3)-C1(4,4))^2.0 )/( 2*C1(3,3)*(C1(3,3)-C1(4,4)) );
gama=(C1(6,6)-C1(4,4))/2.0/C1(4,4);