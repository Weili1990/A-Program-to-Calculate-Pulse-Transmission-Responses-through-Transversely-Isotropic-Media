%The function provides the signals of the ultrasonic transducer in artitrarily oriented transverse isotropy
%Inputs:
    %C1- the original elastic stiffness matrix;
    %vpp, vpsv, and vpsh- the magnitudes of phase velocity of P-wave, SV-wave, and SH-wave
    %vgp, vgsv, and vgsh- the magnitudes of group velocity of P-wave, SV-wave, and SH-wave
    %vgpxyz, vgsvxyz, and vgshxyz- the components of group velocity of P-wave, SV-wave, and SH-wave
    %polipxyz, polisvxyz, and polishxyz- the polarization components of P-wave, SV-wave, and SH-wave
    %di- magnitude of the directivity pattern
    %ln and lin- the vertical griding number and the vertical griding interval of the media
    %win- the horizontal grding interval of the media
    %timestart- the start time of the signal time window
    %dt and ntime- the griding number and griding interval of the signal time window
    %nrecei- the number of the receiver
    %fet- the position of the first point source on the transducer. It is used to move the transmitter.
    %etn and etin- the griding number and the griding interval of the transmitter
    %rtn and rtin- the griding number and the griding interval of the receiver
%Outputs:
    %pickuptime- the picked propagation time from the signal
function pickuptime=Signals(vgp, vgpxyz, vgsv, vgsvxyz, vgsh, vgshxyz, polipxyz, polisvxyz, polishxyz, di, ln, lin, win, timestart, dt, ntime, nrecei, fet, etn, etin, rtn, rtin)
global n f wavemode;
etpo=zeros(1,etn);% position of each point source on the transmitter
vg=zeros(1,n); % group velocity
vgxyz=zeros(3,n); % components of group velocity
polixyz=zeros(3,n); % polarization
retime=zeros(1,ntime); % time
for i=1:n
    % input P, SV or SH wave parameters
    if (abs(wavemode-1)<10^(-6))
        vg(i)=vgp(i);
        vgxyz(1,i)=vgpxyz(1,i);
        vgxyz(3,i)=vgpxyz(3,i);
        polixyz(1,i)=polipxyz(1,i);
        polixyz(3,i)=polipxyz(3,i);
    end
    if (abs(wavemode-2)<10^(-6))
        vg(i)=vgsv(i);
        vgxyz(1,i)=vgsvxyz(1,i);
        vgxyz(3,i)=vgsvxyz(3,i);
        polixyz(1,i)=polisvxyz(1,i);
        polixyz(3,i)=polisvxyz(3,i);
    end
    if (abs(wavemode-3)<10^(-6))
        vg(i)=vgsh(i);
        vgxyz(1,i)=vgshxyz(1,i);
        vgxyz(3,i)=vgshxyz(3,i);
        polixyz(1,i)=polishxyz(1,i);
        polixyz(3,i)=polishxyz(3,i);
    end
end
% positions of the point sources
for i=1:etn
    etpo(i)=(i-1)*etin+(fet-1)*win;
end
receistart=zeros(1,nrecei);% positions of the point receivers on the left sides of all the receivers
out=zeros(nrecei,ntime);% summation of all output waveforms received from every point receiver
output=zeros(nrecei,ntime);% output waveforms of all the receivers
output1=zeros(nrecei,ntime);% output waveforms of all the receivers used to fill color to the positive parts of output
rtpo=zeros(nrecei,rtn);% positions of the point receivers on all the receivers
ptime=zeros(nrecei,rtn);% transit times from point receivers to point sources
dis=zeros(nrecei,rtn);% distances between point receivers and point sources
cosdis=zeros(nrecei,ntime);% direction cosine calculated from interpolation for evert point receiver
vgroup=zeros(nrecei,ntime);% group velocity calculated from interpolation for evert point receiver
amp=zeros(nrecei,rtn);% directivity calculated from interpolation for evert point receiver
for i=1:nrecei
    receistart(i)= i-1;
end
pickuptime= zeros(1,nrecei);
    for i= 1:nrecei
        for j= 1:rtn
            rtpo(i,j)= receistart(i)+(j-1)*rtin;
        end
    end
    for iii=1:ntime
        retime(iii)=(iii-1)*dt+timestart;
        for i=1:nrecei 
            out(i,iii)=0;
            for j=1:rtn
                for k=1:etn
                    dis(i,j)=sqrt( ( rtpo(i,j)-etpo(k) )^2+ ( (ln-1)*lin )^2 );% distance between point (i,j) and the k-th point source according to equation (30)
                    if(abs(dis(i,j))>10^(-6))
                        cosdis(i,j)= ( rtpo(i,j)-etpo(k) )/ dis(i,j);      
                    end
                    if(abs(dis(i,j))<10^(-6))
                        cosdis(i,j)= 0;      
                    end
                    flag=0;
                    % interpolation
                    for ii=1:n-1
                        if (abs(flag)>10^(-6))
                            flag=0;
                            continue;
                        end
                        if (vgxyz(3,ii)<0)
                            continue;
                        end
                        cosdis1=vgxyz(1,ii)/sqrt(vgxyz(1,ii)^2+vgxyz(3,ii)^2);
                        cosdis2=vgxyz(1,ii+1)/sqrt(vgxyz(1,ii+1)^2+vgxyz(3,ii+1)^2);
                        if( (cosdis1-cosdis(i,j))*(cosdis2-cosdis(i,j))<=10^(-6) )
                            flag=ii;
                            vgroup(i,j)=(cosdis(i,j)-cosdis1)/(cosdis2-cosdis1)*(vg(ii+1)-vg(ii))+vg(ii);%group velocity calculated from interpolation method
                            amp(i,j)=(cosdis(i,j)-cosdis1)/(cosdis2-cosdis1)*(di(ii+1)-di(ii))+di(ii);%displacement directivity factor calculated from interpolation method
                            ptime(i,j)=dis(i,j)/vgroup(i,j)*10.0;% transit time according to equation (31)
                            % Calculate the displacement at the points in the receivers according to equation (32)
                            if (abs(wavemode-1)<10^(-6) || abs(wavemode-2)<10^(-6))
                                rayamplitude= amp(i,j)^2/dis(i,j)* ( 1-2*( pi*f*( retime(iii)-ptime(i,j)) )^2 )*exp( -(pi*f*(retime(iii)-ptime(i,j)))^2 );
                                out(i,iii)=out(i,iii)+rayamplitude;
                            end
                            if( abs(wavemode-3)<10^(-6) )
                                rayamplitude= 2^2/dis(i,j)*( 1-2*( pi*f*( retime(iii)-ptime(i,j)) )^2 )*exp( -(pi*f*(retime(iii)-ptime(i,j)))^2 );
                                out(i,iii)= out(i,iii)+ rayamplitude;
                            end
                        end
                    end                  
                end                
            end
            output(i,iii)=out(i,iii);
        end
    end
%% picking up the transit times from the output waveforms
    for i=1:nrecei
        maxamplitude=0;
        for jj=1:ntime
            if(output(i,jj)>maxamplitude)
                maxamplitude=output(i,jj);
                pickuptime(i)=retime(jj);% the transit time picked from the received signal(first positive pick)
            end
        end
    end
%% normalization of the received waveforms
    maxamplitude1=0;
    for i=1:nrecei
        for jj=1:ntime
            if(output(i,jj)>maxamplitude1)
                maxamplitude1=output(i,jj);
            end
        end
    end
    for i=1:nrecei
        for jj=1:ntime
            output(i,jj)=output(i,jj)/maxamplitude1;
        end
    end
    for i=1:nrecei
        for jj=1:ntime
            if (output(i,jj)>0)
                output1(i,jj)=output(i,jj);
            end
        end
    end
    for i=1:nrecei
        for jj=1:ntime
            output(i,jj)=output(i,jj)+i;
            output1(i,jj)=output1(i,jj)+i;
        end
    end
%% Plot received waveforms
figure(5)
set(gcf,'Position',[300 200 400 400]);
hold on
for i=1:nrecei
    plot(output(i,:),retime(1,:),'black');
    % fill color to the positive part of the waveforms
    fill(output1(i,:),retime(1,:),'black','edgealpha',0);
end
box on;
xlabel('Receiver number','FontSize',12,'FontName','Arial');
ylabel('Transit time, us','FontSize',12,'FontName','Arial');
set(gca,'YDir','reverse');
set(findobj('FontSize',12),'FontSize',12,'FontName','Arial');
hold off
