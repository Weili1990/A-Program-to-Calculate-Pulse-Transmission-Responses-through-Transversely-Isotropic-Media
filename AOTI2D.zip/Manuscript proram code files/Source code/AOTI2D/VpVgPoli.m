% Phase velocity, polarization, and group velocity
% Inputs:
    %sita- the phase angle;
    %C- the rotated elastic stiffness matrix;
% Outputs:
    %vpp, vpsv, vpsh- phase velocities of P-wave, SV-wave, and SH-wave
    %vppxyz, vpsvxyz, vpshxyz- components of phase velocities of P-wave, SV-wave, and SH-wave
    %sp, ssv, ssh- slownesses of P-wave, SV-wave, and SH-wave
    %spxyz, ssvxyz, sshxyz- components of slownesses of P-wave, SV-wave, and SH-wave
    %polipxyz, polisvxyz, polishxyz- components of polarizations of P-wave, SV-wave, and SH-wave
    %vgp, vgsv, vgsh- group velocities of P-wave, SV-wave, and SH-wave
    %vgpxyz, vgsvxyz, vgshxyz- components of group velocities of P-wave, SV-wave, and SH-wave
%The globle variables are defined in the main function
function [vpp, vppxyz, vpsv, vpsvxyz, vpsh, vpshxyz, sp, spxyz, ssv, ssvxyz, ssh, sshxyz, polipxyz, polisvxyz, polishxyz, vgp, vgpxyz, vgsv, vgsvxyz, vgsh, vgshxyz]=VpVgPoli(sita, C)
global n density;
taomatrix=zeros(3,3);
direct=zeros(3,n);% the direction vector
vpp=zeros(1,n);% qP-wave phase velocity, km/s
vpsv=zeros(1,n);% qSV-wave phase velocity,km/s
vpsh=zeros(1,n);% SH-wave phase velocity,km/s
vppxyz=zeros(3,n);% qP-wave phase velocity vector
vpsvxyz=zeros(3,n);% qSV-wave phase velocity vector
vpshxyz=zeros(3,n);% SH-wave phase velocity vector
polipxyz=zeros(3,n);% qP-wave polirization vector
polisvxyz=zeros(3,n);% qSV-wave polirization vector
polishxyz=zeros(3,n);% SH-wave polirization vector
sp=zeros(1,n);% qP-wave slowness, us
ssv=zeros(1,n);% qSV-wave slowness, us
ssh=zeros(1,n);% SH-wave slowness, us
spxyz=zeros(3,n);% qP-wave slowness vector
ssvxyz=zeros(3,n);% qSV-wave slowness vector
sshxyz=zeros(3,n);% qSH-wave slowness vector
vgp=zeros(1,n);% qP-wave group velocity, km/s
vgsv=zeros(1,n);% qSV-wave group velocity, km/s
vgsh=zeros(1,n);% SH-wave group velocity, km/s
vgpxyz=zeros(3,n);% qP-wave group velocity, km/s
vgsvxyz=zeros(3,n);% qSV-wave group velocity, km/s
vgshxyz=zeros(3,n);% SH-wave group velocity, km/s
for i=1:n
    for ii=1:3
        for jj=1:3
            taomatrix(ii,jj)=0.0;    
        end
    end
    % Calcualte the direction vector
    direct(1,i)=sin(sita(i));
    direct(2,i)=0;
    direct(3,i)=cos(sita(i));
    % Calculate phase velocity and unit displacement vector (polarization) according to equation (6)
    for iii=1:3
        for jjj=1:3
           for kkk=1:3
               for lll=1:3
                   if (iii==1 && jjj==1)
                       mm=1;
                   end
                   if (iii==2 && jjj==2)
                       mm=2;
                   end
                   if (iii==3 && jjj==3)
                       mm=3;
                   end
                   if ((iii==1 && jjj==2) || (iii==2 && jjj==1))
                       mm=6;
                   end
                   if ((iii==1 && jjj==3) || (iii==3 && jjj==1))
                       mm=5;
                   end
                   if ((iii==2 && jjj==3) || (iii==3 && jjj==2))
                       mm=4;
                   end
                   if (kkk==1 && lll==1)
                       nn=1;
                   end
                   if (kkk==2 && lll==2)
                       nn=2;
                   end
                   if (kkk==3 && lll==3)
                       nn=3;
                   end
                   if ((kkk==1 && lll==2) || (kkk==2 && lll==1))
                       nn=6;
                   end
                   if ((kkk==1 && lll==3) || (kkk==3 && lll==1))
                       nn=5;
                   end
                   if ((kkk==2 && lll==3) || (kkk==3 && lll==2))
                       nn=4;
                   end
                   taomatrix(iii,kkk)=taomatrix(iii,kkk)+C(mm,nn)*direct(jjj,i)*direct(lll,i);
               end
           end
        end
    end
    [lw,lw1]=eig(taomatrix);
    % Identify the wave modes for the solutions
    zzp=1;
    for ii=2:3
         if( lw1(ii,ii)>lw1(zzp,zzp) )
             zzp=ii;
         end
    end
    vpp(i)=sqrt(lw1(zzp,zzp)/density);
    if (abs(vpp(i))<10^(-6))
        vpp(i)=0;
    end
    vppxyz(1,i)=vpp(i)*sin(sita(i));
    if (abs(vppxyz(1,i))<10^(-6))
        vppxyz(1,i)=0;
    end
    vppxyz(3,i)=vpp(i)*cos(sita(i));
    if (abs(vppxyz(3,i))<10^(-6))
        vppxyz(3,i)=0;
    end
    sp(i)=1.0/vpp(i);
    if (abs(sp(i))<10^(-6))
        sp(i)=0;
    end
    spxyz(1,i)=sp(i)*sin(sita(i));
    if (abs(spxyz(1,i))<10^(-6))
        spxyz(1,i)=0;
    end
    spxyz(3,i)=sp(i)*cos(sita(i));
    if (abs(spxyz(3,i))<10^(-6))
        spxyz(3,i)=0;
    end
    polipxyz(1,i)=lw(1,zzp);
    if (abs(polipxyz(1,i))<10^(-6))
        polipxyz(1,i)=0;
    end
    polipxyz(3,i)=lw(3,zzp);
    if (abs(polipxyz(3,i))<10^(-6))
        polipxyz(3,i)=0;
    end
    if ( abs(lw1(1,1)-lw1(2,2))>10^(-6) && abs(lw1(2,2)-lw1(3,3))>10^(-6) && abs(lw1(1,1)-lw1(3,3))>10^(-6) )
        for ii=1:3
             if( abs(zzp-ii)>10^(-6) && abs(lw(2,ii)-0)<10^(-6) )
                 zzsv=ii;
             end
        end
        for ii=1:3
             if( abs(zzp-ii)>10^(-6) && abs(zzsv-ii)>10^(-6) )
                 zzsh=ii;
             end
        end
        polisvxyz(1,i)=lw(1,zzsv);
        if (abs(polisvxyz(1,i))<10^(-6))
            polisvxyz(1,i)=0;
        end
        polisvxyz(3,i)=lw(3,zzsv);
        if (abs(polisvxyz(3,i))<10^(-6))
            polisvxyz(3,i)=0;
        end
        polishxyz(2,i)=lw(2,zzsh);
    end
    % the identification of wave modes of a special case when the two shear waves are in the isotropic plane of TI media.
    if ( abs(lw1(1,1)-lw1(2,2))<10^(-6) || abs(lw1(2,2)-lw1(3,3))<10^(-6) || abs(lw1(1,1)-lw1(3,3))<10^(-6) )   
        if (abs(polipxyz(3,i))>10^(-6))
            for ii=1:3
                if (abs(ii-zzp)>10^(-6))
                zzsv=ii;
                zzsh=ii;
                break;
                end
            end
            polisvxyz(1,i)=1;
            polisvxyz(2,i)=0.0;
            polisvxyz(3,i)=-polipxyz(1,i)/polipxyz(3,i)*polisvxyz(1,i);
            zxc=[polisvxyz(1,i),polisvxyz(3,i)];
            polisvxyz(1,i)=polisvxyz(1,i)/norm(zxc);
            polisvxyz(3,i)=polisvxyz(3,i)/norm(zxc);
            polishxyz(2,i)=1;
        end
        if (abs(polipxyz(3,i))<10^(-6))
            for ii=1:3
                if (abs(ii-zzp)>10^(-6))
                zzsv=ii;
                zzsh=ii;
                break;
                end
            end
            polisvxyz(1,i)=0;
            polisvxyz(2,i)=0.0;
            polisvxyz(3,i)=1.0;
            polishxyz(2,i)=1;
        end
    end 
    vpsv(i)=sqrt(lw1(zzsv,zzsv)/density);
    if (abs(vpsv(i))<10^(-6))
        vpsv(i)=0;
    end
    vpsvxyz(1,i)=vpsv(i)*sin(sita(i));
    if (abs(vpsvxyz(1,i))<10^(-6))
        vpsvxyz(1,i)=0;
    end
    vpsvxyz(3,i)=vpsv(i)*cos(sita(i));
    if (abs(vpsvxyz(3,i))<10^(-6))
        vpsvxyz(3,i)=0;
    end
    vpsh(i)=sqrt(lw1(zzsh,zzsh)/density);
    if (abs(vpsh(i))<10^(-6))
        vpsh(i)=0;
    end
    vpshxyz(1,i)=vpsh(i)*sin(sita(i));
    if (abs(vpshxyz(1,i))<10^(-6))
        vpshxyz(1,i)=0;
    end
    vpshxyz(3,i)=vpsh(i)*cos(sita(i));
    if (abs(vpshxyz(3,i))<10^(-6))
        vpshxyz(3,i)=0;
    end 
    ssv(i)=1.0/vpsv(i);
    if (abs(ssv(i))<10^(-6))
        ssv(i)=0;
    end
    ssvxyz(1,i)=ssv(i)*sin(sita(i));
    if (abs(ssvxyz(1,i))<10^(-6))
        ssvxyz(1,i)=0;
    end
    ssvxyz(3,i)=ssv(i)*cos(sita(i));
    if (abs(ssvxyz(3,i))<10^(-6))
        ssvxyz(3,i)=0;
    end
    ssh(i)=1.0/vpsh(i);
    if (abs(ssh(i))<10^(-6))
        ssh(i)=0;
    end
    sshxyz(1,i)=ssh(i)*sin(sita(i));
    if (abs(sshxyz(1,i))<10^(-6))
        sshxyz(1,i)=0;
    end
    sshxyz(3,i)=ssh(i)*cos(sita(i));
    if (abs(sshxyz(3,i))<10^(-6))
        sshxyz(3,i)=0;
    end   
    % Define the positive direction of unit displacement vector
    if( (polipxyz(1,i)*vppxyz(1,i)+polipxyz(3,i)*vppxyz(3,i))<0 )
        polipxyz(1,i)= -polipxyz(1,i);
        polipxyz(2,i)= -polipxyz(2,i);
        polipxyz(3,i)= -polipxyz(3,i);
    end
    crossplot=cross(polisvxyz,vpsvxyz);
    if( crossplot(2,i)>0 )
        polisvxyz(1,i)= -polisvxyz(1,i);
        polisvxyz(2,i)= -polisvxyz(2,i);
        polisvxyz(3,i)= -polisvxyz(3,i);
    end
    if( polishxyz(2,i)<0 )
        polishxyz(1,i)= -polishxyz(1,i);
        polishxyz(2,i)= -polishxyz(2,i);
        polishxyz(3,i)= -polishxyz(3,i);
    end
    % Calculate group velocity according to equation (7)
    for iii=1:3
        for jjj=1:3
            for kkk=1:3
                for lll=1:3
                    if (iii==1 && jjj==1)
                        mm=1;
                    end
                    if (iii==2 && jjj==2)
                        mm=2;
                    end
                    if (iii==3 && jjj==3)
                        mm=3;
                    end
                    if ((iii==1 && jjj==2) || (iii==2 && jjj==1))
                        mm=6;
                    end
                    if ((iii==1 && jjj==3) || (iii==3 && jjj==1))
                        mm=5;
                    end
                    if ((iii==2 && jjj==3) || (iii==3 && jjj==2))
                        mm=4;
                    end
                    if (kkk==1 && lll==1)
                        nn=1;
                    end
                    if (kkk==2 && lll==2)
                        nn=2;
                    end
                    if (kkk==3 && lll==3)
                        nn=3;
                    end
                    if ((kkk==1 && lll==2) || (kkk==2 && lll==1))
                        nn=6;
                    end
                    if ((kkk==1 && lll==3) || (kkk==3 && lll==1))
                        nn=5;
                    end
                    if ((kkk==2 && lll==3) || (kkk==3 && lll==2))
                        nn=4;
                    end
                    vgpxyz(iii,i)=vgpxyz(iii,i)+C(mm,nn)*spxyz(kkk,i)*polipxyz(jjj,i)*polipxyz(lll,i)/density;
                    vgsvxyz(iii,i)=vgsvxyz(iii,i)+C(mm,nn)*ssvxyz(kkk,i)*polisvxyz(jjj,i)*polisvxyz(lll,i)/density;
                    vgshxyz(iii,i)=vgshxyz(iii,i)+C(mm,nn)*sshxyz(kkk,i)*polishxyz(jjj,i)*polishxyz(lll,i)/density;
                end
            end
        end
    end
    vgp(i)=sqrt(vgpxyz(1,i)^2+vgpxyz(3,i)^2);
    vgsv(i)=sqrt(vgsvxyz(1,i)^2+vgsvxyz(3,i)^2);
    vgsh(i)=sqrt(vgshxyz(1,i)^2+vgshxyz(3,i)^2);
    if (abs(vgpxyz(1,i))<10^(-6))
        vgpxyz(1,i)=0;
    end
    if (abs(vgpxyz(3,i))<10^(-6))
        vgpxyz(3,i)=0;
    end
    if (abs(vgp(i))<10^(-6))
        vgp(i)=0;
    end
    if (abs(vgsvxyz(1,i))<10^(-6))
        vgsvxyz(1,i)=0;
    end
    if (abs(vgsvxyz(3,i))<10^(-6))
        vgsvxyz(3,i)=0;
    end
    if (abs(vgsv(i))<10^(-6))
        vgsv(i)=0;
    end
end
% Plot the phase and group velocity surfaces
figure(1)
hold on
plot(vppxyz(1,:),vppxyz(3,:),'-black',vgpxyz(1,:),vgpxyz(3,:),'--red');
plot(vpsvxyz(1,:),vpsvxyz(3,:),'-black',vgsvxyz(1,:),vgsvxyz(3,:),'--blue');
plot(vpshxyz(1,:),vpshxyz(3,:),'-black',vgshxyz(1,:),vgshxyz(3,:),'--green');
title('Phase and gropu velocity surfaces');
xlabel('Horizontal velocity, km/s'); 
ylabel('Vertical velocity, km/s'); 
hold off

figure(2);
hold on
for i=1:n
    plot([vppxyz(1,i)-polipxyz(1,i)/7.5,vppxyz(1,i)+polipxyz(1,i)/7.5],[vppxyz(3,i)-polipxyz(3,i)/7.5,vppxyz(3,i)+polipxyz(3,i)/7.5]);
    plot([vpsvxyz(1,i)-polisvxyz(1,i)/7.5,vpsvxyz(1,i)+polisvxyz(1,i)/7.5],[vpsvxyz(3,i)-polisvxyz(3,i)/7.5,vpsvxyz(3,i)+polisvxyz(3,i)/7.5],'r');
end
axis([-8 8 -8 8]);
title('Polarization');
hold off

